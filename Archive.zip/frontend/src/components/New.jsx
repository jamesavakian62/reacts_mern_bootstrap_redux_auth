import React from 'react'

const New = () => {
  return (
    <div>new</div>
  )
}

export default New